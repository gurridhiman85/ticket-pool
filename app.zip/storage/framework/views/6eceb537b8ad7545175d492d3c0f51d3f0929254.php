<script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
      crossorigin="anonymous"
    ></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script>
      $(document).ready(function() {
            // Delay the hide operation by 3000 milliseconds (3 seconds)
            setTimeout(function() {
                $('#successMessage').fadeOut('slow');
            }, 3000);
        });
    </script>
    <?php $__env->startSection('footer_js'); ?>
    <?php echo $__env->make('assetlib.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldSection(); ?>
  </body>
</html>
<?php /**PATH /home/u230200563/domains/shopperbite.com/public_html/densu/resources/views/admin/shared/viw_footer.blade.php ENDPATH**/ ?>