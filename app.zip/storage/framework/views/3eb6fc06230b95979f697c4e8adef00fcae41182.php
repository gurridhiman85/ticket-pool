<?php echo $__env->make('shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Hello <?php echo $userName;?></h1>
<a href="<?php echo e(route('logout')); ?>">Logout</a>
<?php echo $__env->make('shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_projects\densu\resources\views/dashboard.blade.php ENDPATH**/ ?>