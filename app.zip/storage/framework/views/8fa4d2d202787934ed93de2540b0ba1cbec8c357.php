<?php echo $__env->make('shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1>Login form</h1>
<div id="error_msg" class="alert" style="display:none;"></div>
<form action="valid-auth" method="post" id="loginform">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="" class="form-label">Email address</label>
    <input type="text" class="form-control" id="email" name="email" >
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Password</label>
    <input type="text" class="form-control" id="password" name="password">
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Remember me</label>
  </div>
  <button type="submit" class="btn btn-primary login_btn">Submit</button>
</form>

<?php echo $__env->make('shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- include js file -->
<script src="public/assets/js/login.js"></script><?php /**PATH C:\xampp\htdocs\laravel_projects\codewithsagar\resources\views/login.blade.php ENDPATH**/ ?>