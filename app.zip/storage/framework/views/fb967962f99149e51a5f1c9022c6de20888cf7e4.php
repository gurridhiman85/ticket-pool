<?php echo $__env->make('admin.shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 class="text-center">Orders Details</h1>
<table class="table table-bordered border-secandory">
  <thead>
    <tr class="table-dark">
      <th scope="col">Order Id</th>
      <th scope="col">Name</th>
      <th scope="col">Account no</th>
      <th scope="col">Total Amount</th>
      <th scope="col">Adderess</th>
      <th scope="col">Order status</th>
      <th scope="col">Order Date/Time</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($orders_info as $info) {?>
    <tr>
      <th><?php echo $info->id;?></th>
      <td><?php echo $info->name;?></td>
      <td><?php echo $info->account_no;?></td>
      <td><?php echo '$'.$info->total;?></td>
      <td><?php echo $info->address;?></td>
      <td><?php echo $info->order_status;?></td>
      <td><?php echo $info->date_added;?></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php echo $__env->make('admin.shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u230200563/domains/shopperbite.com/public_html/densu/resources/views/admin/viw_orders.blade.php ENDPATH**/ ?>