<?php echo $__env->make('shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 class="text-center">Support Ticket</h1>
<div class="row" style="margin:25px 0px">
    <div class="col-lg-4 bg-success text-center text-light p-4">
        <a href="<?php echo e(route('ticket.list')); ?>" class="text-light text-decoration-none">
            <p>All Tickets</p>
            <p><?php echo $ticket_counts;?></p>
        </a>    
    </div>
    <div class="col-lg-4 bg-primary text-center text-light p-4">
        <a href="<?php echo e(route('ticket.list', ['any' => 'open'])); ?>" class="text-light text-decoration-none">
            <p>Open Tickets</p>
            <p><?php echo $open_counts;?></p>
        </a>    
    </div>
    <div class="col-lg-4 bg-danger text-center text-light p-4">
        <a href="<?php echo e(route('ticket.list', ['any' => 'close'])); ?>" class="text-light text-decoration-none">
            <p>Close Tickets</p>
            <p><?php echo $close_counts;?></p>
        </a>
    </div>
</div>
<div id="error_msg" class="alert" style="display:none;"></div>
<form action="<?php echo $action_url;?>" method="post" id="ticketform">
    <?php echo csrf_field(); ?>
 <div class="mb-3">
    <label for="" class="form-label">Enter Name</label>
    <input type="text" class="form-control" id="name" name="name" >
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Email address</label>
    <input type="text" class="form-control" id="email" name="email" >
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Priority</label>
    <select name="priority" id="priority">
        <option value="">Select</option>
        <option value="high">High</option>
        <option value="medium">Medium</option>
        <option value="low">low</option>
    </select>
  </div>
  <div class="mb-3">
    <label for="">Message</label>
  <textarea class="form-control" name="message" placeholder="Leave a comment here" id="message"></textarea>  </div>
  <button type="submit" class="btn btn-primary ticket_btn">Submit</button>
</form>
<?php echo $__env->make('shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- include js file -->
<script src="<?php echo e(asset('public/assets/js/ticket.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\laravel_projects\codewithsagar\resources\views/viw_add_ticket.blade.php ENDPATH**/ ?>