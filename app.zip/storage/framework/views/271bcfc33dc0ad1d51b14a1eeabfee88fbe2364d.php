<?php echo $__env->make('shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 class="text-center"><?php if($status == 'open'){ echo 'Open Ticket';}elseif($status == 'close'){ echo 'Close Ticket';}else{
   echo 'Ticket List'; }?></h1>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Priority</th>
      <th scope="col">Message</th>
      <?php if($status == ''){?>
      <th scope="col">Status</th>
      <?php }?>
      <th scope="col">Created Date</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
$count = 1;
$model_count = 1;

foreach ($ticket_info as $info) {
    ?>
    <tr>
        <td><?php echo $count++; ?></td>
        <td><?php echo $info->name; ?></td>
        <td class="<?php if($info->priority == 'high'){ echo 'text-danger';}elseif($info->priority == 'medium'){ echo 'text-warning';}else{echo 'text-primary';} ?>"><?php echo ucfirst($info->priority); ?></td>
        <td><?php echo substr($info->msg, 0, 30) . '....'; ?></td>
        <?php if($status == ''){?>
        <td><span><?php echo ucfirst($info->status); ?></span></td>
        <?php }?>
        <td><?php echo $info->created; ?></td>
        <td>
            <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                    data-bs-target="#view_msg<?php echo $model_count; ?>">View
            </button>
        </td>
    </tr>
    <!-- Modal -->
    <div class="modal fade" id="view_msg<?php echo $model_count; ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Replied Message(Adminstrator)</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div>
                        <label for="">Message</label>
                        <textarea name="" id="" class="form-control" cols="30"
                                  rows="10"><?php echo $info->replied_msg; ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button> -->
                </div>
            </div>
        </div>
    </div>
    <?php
    $model_count++; // Increment $model_count after using it
}
?>
  </tbody>
</table>


<?php echo $__env->make('shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_projects\codewithsagar\resources\views/viw_ticket_list.blade.php ENDPATH**/ ?>