<?php


$js_files = [
    'jquery' => [
        'path' => 'theme-assets/jquery/jquery-3.2.1.min.js',
        'required' => 1
    ]
];


// \App\Library\AssetLib::echoJsFiles($js_files);
 ?><?php /**PATH /home/u230200563/domains/shopperbite.com/public_html/densu/resources/views/assetlib/head_js.blade.php ENDPATH**/ ?>