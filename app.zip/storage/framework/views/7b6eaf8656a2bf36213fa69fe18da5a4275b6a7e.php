<?php echo $__env->make('admin.shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--orders-->
        <div class="col-md-4 ">
          <div class="card">
            <div class="card-header text-primary fw-bold">
              Orders 
            </div>
            <div class="card-body " style="max-height: 300px; overflow-y:auto;">
               <div>
                <table class="table table-bordered border-secondary-subtle table-striped">
                  <tbody>
                    <tr style="color:White;background-color:Black;font-weight:bold;">
                      <th scope="col">&nbsp</th>
                      <th scope="col">Details</th>
                    </tr>
                    <?php foreach($order_info as $info) {?>
                    <tr>
                      <td>
                      <a class="btn btn-info" href="<?php echo e(route('admin.order', ['orderid' => $info->id])); ?>">Open</a>
                      </td>
                      <td>
                        <h6><?php echo $info->account_no;?>,<?php echo $info->name;?></h6>
                        <?php echo $info->address;?>
                      </td>
                    </tr>      
                    <?php }?>    
                  </tbody>
                </table>

               </div>
            </div>
          </div>         
        </div>

        <!--stock controls-->
        <div class="col-md-4">
          <div class="card">
            <div class="card-header text-primary fw-bold">
               Stock Control
            </div>
            <div class="card-body "  style="max-height: 300px; overflow-y:auto;">
               <div>
                <table class= " table-striped  table-bordered border-secondary-subtle " >
                  <tbody>
                    <tr style="color:White;background-color:Black;font-weight:bold;">
                      <th scope="col">&nbsp</th>
                      <th scope="col">Details</th>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <a class="btn btn-info" href="#">Open</a>
                      </td>
                      <td>
                        <h6>some dummy data</h6>
                        Expected:here add dummy data
                      </td>
                    </tr>             
                  </tbody>

                </table>
               </div>
            </div>
          </div>         
        </div>

        </div>
      </div>
      <!--Stock controls-->
    </div>
<?php echo $__env->make('admin.shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/u230200563/domains/shopperbite.com/public_html/densu/resources/views/admin/viw_dashboard.blade.php ENDPATH**/ ?>