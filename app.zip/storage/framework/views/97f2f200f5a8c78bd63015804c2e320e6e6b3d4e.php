<?php echo $__env->make('front.shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-container">
            <div class="container">
                <div class="row">
                    <dov class="col-lg-12">
                        <div class="product-details d-flex flex-wrap">
                            <div class="product-details-left">
                                <div class="product-imgs">
                                    <div class="img-display">
                                        <div class="img-showcase">
                                            <img src="<?php echo e(asset('storage/app/public/images/inventory/' . $inventory_info->image)); ?>" alt="pd-img">
                                            <img src="public/front/assets/images/product-img-2.png" alt="pd-img">
                                            <img src="public/front/assets/images/product-img-3.png" alt="pd-img">
                                            <img src="public/front/assets/images/product-img-4.png" alt="pd-img">
                                        </div>
                                    </div>
                                    <div class="img-select">
                                        <div class="img-item">
                                            <a href="#" data-id="1">
                                                <img src="<?php echo e(asset('storage/app/public/images/inventory/' . $inventory_info->image)); ?>" alt="pd-img">
                                            </a>
                                        </div>
                                        <div class="img-item">
                                            <a href="#" data-id="2">
                                                <img src="public/front/assets/images/product-img-2.png" alt="pd-img">
                                            </a>
                                        </div>
                                        <div class="img-item">
                                            <a href="#" data-id="3">
                                                <img src="public/front/assets/images/product-img-3.png" alt="pd-img">
                                            </a>
                                        </div>
                                        <div class="img-item">
                                            <a href="#" data-id="4">
                                                <img src="public/front/assets/images/product-img-4.png" alt="pd-img">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="product-details-right">
                                <div class="product-details-content">
                                    <div class="amount-box d-flex align-content-center">
                                        <h4> Price :- </h4>
                                        <div class="amount"><?php echo $inventory_info->price;?> </div>
                                    </div>
                                    <div class="pd-heading">
                                        <h4><?php echo $inventory_info->item_name;?></h4>
                                        <p> 100% Polyester - 175 gsm. 144 Filament supreme microfibre polyester, moisture wicking properties, 
                                            highly breathable and quick dry, button free placket - food industry safe. </p>
                                    </div>
                                    <div class="size">
                                        <h6> Size :- </h6>
                                        <div class="psize active">M</div>
                                        <div class="psize">L</div>
                                        <div class="psize">XL</div>
                                        <div class="psize">XXL</div>
                                    </div>
                                    <div class="quantity d-flex flex-wrap align-items-center">
                                        <h6> Quantity :- </h6>
                                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="add-to-cart-form" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>    
                                        <div class="qty">
                                                <button class="qtyminus" aria-hidden="true">&minus;</button>
                                                    <input type="number" name="product_qty" id="product_qty" min="1" max="10" step="1" value="1">
                                                <button type="button" class="qtyplus" aria-hidden="true">&plus;</button>
                                            </div>
                                    </div>
                                    <div class="pd-details-btn"> 
                                <input type="hidden" name="product_id" value="<?php echo e($inventory_info->id); ?>">
                                <input type="hidden" name="product_name" value="<?php echo e($inventory_info->item_name); ?>">
                                <input type="hidden" name="product_price" value="<?php echo e($inventory_info->price); ?>">
                                <input type="hidden" name="product_image" value="<?php echo e($inventory_info->image); ?>">
                                <button type="submit" class="btn">Add To Cart</button>
                            </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </dov>
                </div>
            </div>
        </div>
        <!--============================== Content Container Start ==============================-->
    </main>
<?php echo $__env->make('front.shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_projects\densu\resources\views/front/viw_product_info.blade.php ENDPATH**/ ?>