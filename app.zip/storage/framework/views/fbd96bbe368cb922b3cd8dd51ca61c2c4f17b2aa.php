<?php echo $__env->make('admin.shared.viw_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--order sections-->

    <div class="container">
      <h1 class="mt-5">
        Orders (29) |
        <button type="submit" class="btn btn-primary">+</button>
      </h1>

      <form>
        <div class="row">
          <div class="col-md-4">
            Start Date
            <input
              name="txtDateStart"
              type="date"
              value="2023-08-16"
              id="DateStart"
              class="form-control"
            />
          </div>
          <div class="col-md-4">
            End Date
            <input
              name="DateEnd"
              type="date"
              value="2023-11-16"
              id="DateEnd"
              class="form-control"
            />
          </div>
          <div class="col-md-2 m-auto">
            <input id="ShowUserOrders" type="checkbox" name="ShowUserOrders" />
            <label for="ShowUserOrders">My Orders Only</label>
          </div>
          <div class="col-md-2 mt-4">
            <button type="submit" class="btn btn-success">Search</button>
          </div>
        </div>
      </form>


      <!---->
      <div>
      <ul class="nav nav-tabs mt-5">
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">New Incomplete order(0)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Quotes(09)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Pending Internal approval(0)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Pending Customer approval(0)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Awaiting deposite(31)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Pending Orders(07)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#"> All(09)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#"> Productions(12)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Printing A(06)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Printing B(04)</a>
        </li>
        <li class="nav-item" style="margin-top: 5px; margin-right: 5px">
          <a class="btn btn-primary" href="#">Ebroidery A(03)</a>
        </li>
      </ul>
    </div>

      <!--tablist-->
      <div class="table-responsive">
        <h1 class="text">All</h1>
      <table
         class= "table table-bordered border-primary"
        style="
          color: Black;
          background-color: White;
          border-color: #999999;
          border-width: 1px;
          border-style: Solid;
          width: 100%;
          border-collapse: collapse;
        "
        >
        <tbody  >
          <tr class="table-dark">
            <th scope="col" style="width: 53px">&nbsp;</th>
            <th scope="col" style="width: 53px">&nbsp;</th>
            <th scope="col" style="width: 12%">Order Number</th>
            <th scope="col" style="width: 12%">Created Date</th>
            <th scope="col" style="width: 12%">Expected By</th>
            <th scope="col" style="width: 18%">Customer</th>
            <th scope="col" style="width: 15%">Sales Representative</th>
            <th scope="col" style="width: 15%">
              Total Sales Price<br />(Inc GST)
            </th>
            <th scope="col">Entered By</th>
            <th scope="col">Quote</th>
          </tr>
          <tr>
            <td>
              <a id=" btnDelete_0" class="btn btn-danger btnmargin" href="#"
                >X</a
              >
            </td>
            <td>
              <a href="#" class="btn btn-warning btnmargin">Edit</a>
            </td>
            <td>1700977</td>
            <td>16/11/2023</td>
            <td></td>
            <td>
              <a href="#">HIAb (Deleted)</a>
            </td>
            <td>Denis Okah</td>
            <td>
              <span id=" SalesPriceExGST">$0.00</span>
            </td>
            <td>&nbsp;</td>
            <td>True</td>
          </tr>
          <tr>
            <td>
              <a id=" btnDelete_0" class="btn btn-danger btnmargin" href="#"
                >X</a
              >
            </td>
            <td>
              <a href="#" class="btn btn-warning btnmargin">Edit</a>
            </td>
            <td>1700977</td>
            <td>16/11/2023</td>
            <td></td>
            <td>
              <a href="#">HIAb (Deleted)</a>
            </td>
            <td>Denis Okah</td>
            <td>
              <span id=" SalesPriceExGST">$0.00</span>
            </td>
            <td>&nbsp;</td>
            <td>True</td>
          </tr>
          <tr>
            <td>
              <a id=" btnDelete_0" class="btn btn-danger btnmargin" href="#"
                >X</a
              >
            </td>
            <td>
              <a href="#" class="btn btn-warning btnmargin">Edit</a>
            </td>
            <td>1700977</td>
            <td>16/11/2023</td>
            <td></td>
            <td>
              <a href="#">HIAb (Deleted)</a>
            </td>
            <td>Denis Okah</td>
            <td>
              <span id=" SalesPriceExGST">$0.00</span>
            </td>
            <td>&nbsp;</td>
            <td>True</td>
          </tr>
          <tr>
            <td>
              <a id=" btnDelete_0" class="btn btn-danger btnmargin" href="#"
                >X</a
              >
            </td>
            <td>
              <a href="#" class="btn btn-warning btnmargin">Edit</a>
            </td>
            <td>1700977</td>
            <td>16/11/2023</td>
            <td></td>
            <td>
              <a href="#">HIAb (Deleted)</a>
            </td>
            <td>Denis Okah</td>
            <td>
              <span id=" SalesPriceExGST">$0.00</span>
            </td>
            <td>&nbsp;</td>
            <td>True</td>
          </tr>
          <tr>
            <td>
              <a id=" btnDelete_0" class="btn btn-danger btnmargin" href="#"
                >X</a
              >
            </td>
            <td>
              <a href="#" class="btn btn-warning btnmargin">Edit</a>
            </td>
            <td>1700977</td>
            <td>16/11/2023</td>
            <td></td>
            <td>
              <a href="#">HIAb (Deleted)</a>
            </td>
            <td>Denis Okah</td>
            <td>
              <span id=" SalesPriceExGST">$0.00</span>
            </td>
            <td>&nbsp;</td>
            <td>True</td>
          </tr>
          <tr style="background-color: #cccccc">
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
    </div>

    

<?php echo $__env->make('admin.shared.viw_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel_projects\densu\resources\views/admin/viw_order.blade.php ENDPATH**/ ?>