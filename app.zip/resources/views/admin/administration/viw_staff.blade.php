@include('admin.shared.viw_header')

    <!--staff create-->
    <div class="container mt-5">
         <h1>Densu Group Staff</h1>
        <div class="tab-content">
            <h1 class="text">Staff <button type="submit" class="btn btn-primary">+</button></h1>
          <table
             class= "table table-st table-bordered border-primary"
             style="
              color: Black;
              background-color: White;
              border-color: #999999;
              border-width: 1px;
              border-style: Solid;
              width: 100%;
              border-collapse: collapse;
            "
            >
            <tbody  >
              <tr class="table-dark">
                <th scope="col" style="width: 53px">&nbsp;</th>
                <th scope="col" style="width: 12%">First Name</th>
                <th scope="col" style="width: 12%">Last Name</th>
                <th scope="col" style="width: 12%"> Position</th>
                <th scope="col" style="width: 18%">Admin Portal Access</th>
                <th scope="col" style="width: 15%">Deleted</th>
                <th scope="col" style="width: 15%">
                  Restricted
                </th>
              </tr>
              <tr>
                <td>
                  <a href="#" class="btn btn-warning btnmargin">View</a>
                </td>
                <td>Alex</td>
                <td>Meyers</td>
                <td>Software</td>
                <td>
                  <input type="checkbox"/>
                </td>
                <td>  <input type="checkbox"/></td>
                <td>
                    <input type="checkbox"/>
                </td>
              </tr>
              <tr>
                <td>
                  <a href="#" class="btn btn-warning btnmargin">View</a>
                </td>
                <td>Alex</td>
                <td>Meyers</td>
                <td>Software</td>
                <td>
                  <input type="checkbox"/>
                </td>
                <td>  <input type="checkbox"/></td>
                <td>
                    <input type="checkbox"/>
                </td>
              </tr>
              <tr>
                <td>
                  <a href="#" class="btn btn-warning btnmargin">View</a>
                </td>
                <td>Alex</td>
                <td>Meyers</td>
                <td>Software</td>
                <td>
                  <input type="checkbox"/>
                </td>
                <td>  <input type="checkbox"/></td>
                <td>
                    <input type="checkbox"/>
                </td>
              </tr>
              <tr style="background-color: #382e2e">
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
    </div>
    @include('admin.shared.viw_footer')
