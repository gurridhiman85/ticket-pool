@include('admin.shared.viw_header')
    <!--inventory create-->
    <div class="container mt-5">
        <h1>Inventory  | 
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#inventory_model ">+</button></h1>
        @if(session('success'))
        <div id="successMessage" class="alert alert-success">{{ session('success') }}</div>
        @endif
            <!-- <form>
              <div class="mb-3">
                <input type="search" class="form-control" id="search" placeholder="search" aria-describedby="searchHelp">
               </div>
              </form> -->

        <div class="d-grid mt-4 ">
          <a class="btn btn-primary" href="{{ route('admin/inventory/list') }}" type="button">View All Inventory</a>
         </div>
    </div>

    <!--Inventory Modal -->
<div class="modal fade" id="inventory_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Inventory</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form action="{{ route('admin/inventory/insert') }}" method="post" enctype="multipart/form-data">
          @csrf
          <div class="row">
            <div class="mb-3 col-lg-6">
              <label for="" class="form-label">Item Code (*):</label>
              <input type="text" class="form-control" id="item_code" name="item_code" required>
                  <!-- @error('item_code')
                <div>{{ $message }}</div>
            @enderror -->
            </div>
            <div class="mb-3 col-lg-6">
              <label for="" class="form-label">Supplier:</label>
              <input type="text" class="form-control"id="supplier" name="supplier" required>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 col-lg-6">
              <label for="" class="form-label">Item Name (*):</label>
              <input type="text" class="form-control" id="item_name" name="item_name" required>
            </div>
            <div class="mb-3 col-lg-6">
              <label for="" class="form-label">Selling Name (*):</label>
              <input type="text" class="form-control"id="selling_name" name="selling_name" required>
            </div>
            <div class="mb-3 col-lg-6">
              <label for="" class="form-label">Item Image:</label>
              <input type="file" id="item_image" name="item_image">
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>
@include('admin.shared.viw_footer')
