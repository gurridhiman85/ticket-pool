@include('admin.shared.viw_header')
@yield('content')

@include('admin.shared.viw_footer')