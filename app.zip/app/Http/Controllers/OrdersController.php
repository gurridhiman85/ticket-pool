<?php 
// CartController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class OrdersController extends Controller
{

    public function index(){
        $data['userName'] = session('user_name');

        $selectedFields = ['id','name', 'account_no','address', 'total', 'order_status','date_added']; // Replace with your actual field names

        $data['orders_info'] = DB::table('customer')
        ->select($selectedFields)
        ->get();

        $data['total_orders'] = DB::table('customer')->count();
        return view('admin.viw_orders',$data);

    }
    public function order_detail($orderid){
        // echo $orderid;die;
        $data['userName'] = session('user_name');

        $selectedFields = ['id','name', 'account_no','address', 'total', 'order_status','date_added']; // Replace with your actual field names

        $data['order_detail'] = DB::table('customer')
            ->select($selectedFields)
            ->where('id', '=', $orderid) // Replace with your actual column and value
            ->first();
        $data['total_orders'] = DB::table('customer')->count();
    
            return view('admin.viw_order_detail',$data);
    }
}