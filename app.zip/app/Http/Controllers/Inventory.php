<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;


    class Inventory extends Controller
    {
        public function index(){

            $data['userName'] = session('user_name');
            $data['total_orders'] = DB::table('customer')->count();

            return view('admin.administration.viw_inventory',$data);
        }

        /******************************** Insert inventory********************************************* */

        public function insert_inventory(Request $req){
            $post_data = $req->input();
            // echo '<pre>';print_r($post_data);die;
                $req->validate([
                    'item_code' => 'required',
                    'supplier' => 'required',
                    'item_name' => 'required',
                    'selling_name' => 'required',
                    // 'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
                ]);

                $originalImageName = $req->file('item_image')->getClientOriginalName();
                $imagePath = $req->file('item_image')->storeAs("images/inventory", $originalImageName, 'public');

                DB::table('inventory')->insert([
                    'item_code' => $post_data['item_code'],
                    'supplier' => $post_data['supplier'],
                    'item_name' => $post_data['item_name'],
                    'selling_name' => $post_data['selling_name'],
                    'image' => $originalImageName,

                ]);
                return redirect()->route('admin/inventory')->with('success', 'Inventory Added Successully !');
            
        }

        /******************************** List inventory********************************************* */
        public function get_inventory(){
            $data['userName'] = session('user_name');
            $selectedFields = ['id','item_code', 'price','supplier', 'item_name', 'selling_name', 'image']; // Replace with your actual field names

            $data['inventory_info'] = DB::table('inventory')
                ->select($selectedFields)
                ->where('status', '=', 1) // Replace with your actual column and value
                ->get();
                $data['total_orders'] = DB::table('customer')->count();
    
            return view('admin.administration.viw_inventory_list',$data);
        }

        /******************************** update inventory********************************************* */
        public function update_inventory(Request $req){
            $post_data = $req->input();
                    // Check if the item with the given item_code exists
            $existingItem = DB::table('inventory')->where('id', $post_data['id'])->first();

            if (!$existingItem) {
                return redirect()->route('admin/inventory/list')->with('error', 'Item not found.');
            }

            // Check if a new image is uploaded
            if ($req->hasFile('item_image')) {
                $originalImageName = $req->file('item_image')->getClientOriginalName();
                $imagePath = $req->file('item_image')->storeAs("images/inventory", $originalImageName, 'public');
            } else {
                // If no new image is uploaded, keep the existing image path
                $originalImageName = $existingItem->image;
            }

            // Update the record in the database
            DB::table('inventory')
                ->where('id', $post_data['id'])
                ->update([
                    'item_code' => $post_data['item_code'],
                    'supplier' => $post_data['supplier'],
                    'item_name' => $post_data['item_name'],
                    'selling_name' => $post_data['selling_name'],
                    'image' => $originalImageName,
                ]);
                $data['total_orders'] = DB::table('customer')->count();
            return redirect()->route('admin/inventory/list')->with('success', 'Inventory Updated Successfully!');

        }

        /******************************** Delete inventory********************************************* */
        public function delete_inventory($id){
            $existingItem = DB::table('inventory')->where('id', $id)->first();

            if (!$existingItem) {
                return redirect()->route('admin/inventory/list')->with('error', 'Item not found.');
            }
        
            // Delete the record from the database
            DB::table('inventory')->where('id', $id)->delete();
            $data['total_orders'] = DB::table('customer')->count();

            return redirect()->route('admin/inventory/list')->with('success', 'Inventory Deleted Successfully!');
        }
    }

?>    