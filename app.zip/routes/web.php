<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Login;
use App\Http\Controllers\Inventory;
use App\Http\Controllers\Home;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\OrdersController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/********************************* Admin Routes********************************************* */
// Route::view('admin','admin.viw_login')->name('admin');

Route::view('admin','admin.viw_login')->name('admin');
Route::post('valid-auth',[Login::class,'valid_auth']);
Route::get('admin/dashboard',[Login::class,'dashboard'])->name('admin/dashboard');
Route::get('logout',[Login::class,'logout'])->name('logout');
Route::get('admin/inventory',[Inventory::class,'index'])->name('admin/inventory');
Route::post('admin/inventory/insert',[Inventory::class,'insert_inventory'])->name('admin/inventory/insert');
Route::get('admin/inventory/list',[Inventory::class,'get_inventory'])->name('admin/inventory/list');
Route::post('admin/inventory/update',[Inventory::class,'update_inventory'])->name('admin/inventory/update');
Route::get('admin/inventory/delete/{id}',[Inventory::class,'delete_inventory'])->name('admin/inventory/delete');
Route::view('admin/message','admin.viw_message')->name('admin.message');
Route::get('admin/order/{orderid}',[OrdersController::class,'order_detail'])->name('admin.order');
Route::get('admin/orders',[OrdersController::class,'index'])->name('admin.orders');






/********************************* Front Routes********************************************* */
// Route::get('/', function () {
//     return view('front.viw_index');
// });
Route::get('/',[Home::class,'index']);
// Route::view('product','front.viw_product')->name('product');
Route::view('customer-experience','front.viw_customer_experience')->name('customer-experience');
Route::view('about','front.viw_about')->name('about');
Route::view('organization','front.viw_organization')->name('organization');
Route::post('add-to-cart', [CartController::class, 'addToCart'])->name('cart.add');
Route::get('view-cart', [CartController::class, 'view_cart'])->name('viewcart');
Route::get('cart/remove/{id}',[CartController::class,'remove_product'])->name('remove_product');
Route::get('shop/item/{productid}',[ProductController::class,'index'])->name('shop.item');
Route::get('shop/cart/checkout',[CheckoutController::class,'index'])->name('shop.cart.checkout');
Route::post('shop/place/order',[CheckoutController::class,'order_insert'])->name('shop.place.order');
Route::get('product',[ProductController::class,'products_listing'])->name('product');


